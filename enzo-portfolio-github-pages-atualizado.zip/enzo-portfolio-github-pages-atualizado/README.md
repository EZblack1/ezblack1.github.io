# Portfólio — Enzo Marques

Portfólio profissional em um único arquivo `index.html`, com CSS e JavaScript incorporados.

## Publicação no GitHub Pages

1. Crie ou abra o repositório `EZblack1.github.io`.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Em **Settings → Pages**, selecione a branch `main` e a pasta `/ (root)`.
4. Acesse `https://ezblack1.github.io/` após a publicação.

## Contatos configurados

- LinkedIn: `www.linkedin.com/in/enzo-oliveira-dev`
- E-mail: `enzomolivei@gmail.com`
- WhatsApp: `+55 27 99275-3180`
- GitHub: `github.com/EZblack1`
